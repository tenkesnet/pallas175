package Pallas;

public class Kor {
	 private double sugar;

	    public Kor(double sugar) {
	        this.sugar = sugar;
	    }

	    public double terulet() {
	        return Math.PI * sugar * sugar;
	    }

	    public double kerulet() {
	        return 2 * Math.PI * sugar;
	    }
}
