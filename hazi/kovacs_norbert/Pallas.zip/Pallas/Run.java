package Pallas;

public class Run {

	public static void main(String[] args) {
	    Kor kor1 = new Kor(5.0); // Első kör, sugara 5.0
	    Kor kor2 = new Kor(7.0); // Második kör, sugara 7.0

	    System.out.println("Első kör területe: " + kor1.terulet());
	    System.out.println("Első kör kerülete: " + kor1.kerulet());

	    System.out.println("Második kör területe: " + kor2.terulet());
	    System.out.println("Második kör kerülete: " + kor2.kerulet());
	}
	
	}


