/**
 * 
 */
/**
 * 
 */
module Hazi2 {
}