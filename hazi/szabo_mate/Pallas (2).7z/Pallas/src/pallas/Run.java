package pallas;

public class Run {
	public static void main(String[] args) {
		
		Kor Kor1 = new Kor(12);
		Kor Kor2 = new Kor(33);
		System.out.println("Kor 1: ");
		Kor1.terulet();
		Kor1.kerulet();
		System.out.println("Kor 2: ");
		Kor2.terulet();
		Kor2.kerulet();
		
		
	}
}
