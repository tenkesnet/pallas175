package pallas;

public class Kor {
	public double sugar;

	public Kor(){
	}
	
	public Kor (double sugar){
		this.sugar=sugar;
	}
	public void terulet() {
		double eredmeny;
		eredmeny = Math.PI * (sugar * sugar);
		System.out.println("Kor terulete: " + eredmeny);
	
	}
	public void kerulet() {
		double eredmeny;
		eredmeny = 2 * Math.PI * sugar;
		System.out.println("Kerulet: " + eredmeny);
	
	}	
}


