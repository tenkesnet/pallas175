package jedi;

public interface EroErzekeny {
    public boolean legyoziE ( EroErzekeny o ) ;
    public double mekkoraAzEreje () ;

}
