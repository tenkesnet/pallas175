package jedi;

public interface Sith {
    public void engeddElAHaragod () ;
}
